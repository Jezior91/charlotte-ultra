# Charlotte Ultra — Historia zmian

## v6.3 — Pioneer Edition (2026-08)
- Intent Ledger: AI zapamiętuje i wznawia zadania
- Soul Lease Mesh: multi-agent w kartach przeglądarki
- Browser Code Lab: sandbox AI z dowodami wykonania

## v6.2 — UX Edition (2026-07)
- Quick Action Bar, Onboarding Wizard
- Skróty Ctrl+1-4
- Panele: Notepad AI, Kalkulator Budżetu, Generator Haseł, System Check
- Dark/light mode toggle

## v6.1 — Security Edition (2026-06)
- XSS protection (sanitizeHTML)
- SecureStorage AES-GCM
- Memory leak fix (CharlotteIntervals)
- DRY LocalStore wrapper

## v6.0 — Base Edition (2026-05)
- Wersja bazowa z 14 panelami
- Fallback LLM: Ollama→DeepSeek→OpenAI→offline
- Trading Bot, Crypto Suite, Legal AI PL, WinPot, CMS
