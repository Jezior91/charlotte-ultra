# Charlotte Ultra v6.1 — Security Edition

**Właściciel:** Tomasz Jeziorski <master.wapmag@gmail.com>
**Licencja:** Proprietary / Trade Secret
**Rok:** 2025-2026

## Uruchomienie
Otwórz plik `CHARLOTTE_ULTRA_v6.1.html` w przeglądarce (Chrome/Firefox/Edge).
Nie wymaga instalacji, serwera ani internetu.

## Co zawiera ta wersja
v6.0 + zabezpieczenia: sanitizeHTML() (ochrona przed XSS), SecureStorage z
AES-GCM (szyfrowane klucze w localStorage), CharlotteIntervals (jeden
zarządca setInterval, brak memory leaks), LocalStore DRY (jeden wrapper
localStorage), ostrzeżenie o Feistel cipher (nie do produkcji), limit
iteracji Monte Carlo.

Uwaga: ten plik archiwalny zbudowano na bazie kodu źródłowego v6.3 z dodanym
banerem i changelogiem wersji v6.1. Funkcje wprowadzone w v6.2 (UX) i v6.3
(Pioneer) mogą pozostawać obecne w kodzie źródłowym jako dziedzictwo bazy,
ale nie są traktowane jako część specyfikacji tej edycji.

## Wymagania
- Nowoczesna przeglądarka (Chrome 90+, Firefox 88+, Edge 90+)
- Opcjonalnie: Ollama lokalnie dla AI offline

## Wsparcie
master.wapmag@gmail.com
