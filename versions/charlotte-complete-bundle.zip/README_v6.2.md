# Charlotte Ultra v6.2 — UX Edition

**Właściciel:** Tomasz Jeziorski <master.wapmag@gmail.com>
**Licencja:** Proprietary / Trade Secret
**Rok:** 2025-2026

## Uruchomienie
Otwórz plik `CHARLOTTE_ULTRA_v6.2.html` w przeglądarce (Chrome/Firefox/Edge).
Nie wymaga instalacji, serwera ani internetu.

## Co zawiera ta wersja
v6.1 + usprawnienia UX: Quick Action Bar (pasek u góry z 6 przyciskami),
Onboarding Wizard (modal przy pierwszym uruchomieniu), skróty klawiszowe
Ctrl+1..Ctrl+4, nowe panele: Notepad AI, Kalkulator Budżetu, Generator
Haseł Pro, System Check (diagnostyka przeglądarki), Dark/light mode toggle.

Uwaga: ten plik archiwalny zbudowano na bazie kodu źródłowego v6.3 z dodanym
banerem i changelogiem wersji v6.2. Funkcje wprowadzone w v6.3 (Pioneer)
mogą pozostawać obecne w kodzie źródłowym jako dziedzictwo bazy, ale nie są
traktowane jako część specyfikacji tej edycji.

## Wymagania
- Nowoczesna przeglądarka (Chrome 90+, Firefox 88+, Edge 90+)
- Opcjonalnie: Ollama lokalnie dla AI offline

## Wsparcie
master.wapmag@gmail.com
