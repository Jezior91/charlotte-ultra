# Charlotte Ultra v6.0 — Base Edition

**Właściciel:** Tomasz Jeziorski <master.wapmag@gmail.com>
**Licencja:** Proprietary / Trade Secret
**Rok:** 2025-2026

## Uruchomienie
Otwórz plik `CHARLOTTE_ULTRA_v6.0.html` w przeglądarce (Chrome/Firefox/Edge).
Nie wymaga instalacji, serwera ani internetu.

## Co zawiera ta wersja
Wersja bazowa Charlotte Ultra z 14 panelami: Chat AI, Trading Bot, Crypto Suite,
Memory, RAG, Voice, Skills, Observability, Legal PL, WinPot, CMS, Deploy,
Business Plan, Crypto Cipher. Fallback LLM: Ollama → DeepSeek → OpenAI → offline.

Uwaga: ten plik archiwalny zbudowano na bazie kodu źródłowego v6.3 z dodanym
banerem i changelogiem wersji v6.0. Funkcje wprowadzone w v6.1 (bezpieczeństwo),
v6.2 (UX) i v6.3 (Pioneer) mogą pozostawać obecne w kodzie źródłowym jako
dziedzictwo bazy, ale nie są traktowane jako część specyfikacji tej edycji.

## Wymagania
- Nowoczesna przeglądarka (Chrome 90+, Firefox 88+, Edge 90+)
- Opcjonalnie: Ollama lokalnie dla AI offline

## Wsparcie
master.wapmag@gmail.com
