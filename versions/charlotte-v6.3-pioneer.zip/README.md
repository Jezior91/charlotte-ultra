# Charlotte Ultra v6.3 — Pioneer Edition

**Właściciel:** Tomasz Jeziorski <master.wapmag@gmail.com>
**Licencja:** Proprietary / Trade Secret
**Rok:** 2025-2026

## Uruchomienie
Otwórz plik `CHARLOTTE_ULTRA_v6.3.html` w przeglądarce (Chrome/Firefox/Edge).
Nie wymaga instalacji, serwera ani internetu.

## Co zawiera ta wersja
v6.2 + funkcje Pioneer: Intent Ledger (localStorage + harmonogram zadań,
AI zapamiętuje i wznawia zadania), Soul Lease Mesh (BroadcastChannel
multi-agent między kartami przeglądarki), Browser Code Lab (sandboxed
iframe z dowodami wykonania SHA-256). Panele: IntentLedger, SoulMesh,
CodeLab. Pełna, kompletna wersja Charlotte Ultra.

## Wymagania
- Nowoczesna przeglądarka (Chrome 90+, Firefox 88+, Edge 90+)
- Opcjonalnie: Ollama lokalnie dla AI offline

## Wsparcie
master.wapmag@gmail.com
